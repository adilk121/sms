
<?php $__env->startSection('content'); ?>
<div class="main-wrapper login-body">
    <div class="login-wrapper">
        <div class="container">
            <div class="loginbox">
                <div class="login-left">
                    <img class="img-fluid" src="<?php echo e(asset('img/logo-white.png')); ?>" alt="Logo" />
                </div>
                <div class="login-right">
                    <div class="login-right-wrap">
                        <h1>Login</h1>
                        <p class="account-subtitle">Access to our dashboard</p>

                        <form action="<?php echo e(route('login')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <input class="form-control" type="text" name="email" id="email" placeholder="Email" />
                            </div>
                            <div class="form-group">
                                <input class="form-control" type="text" name="password" id="password" placeholder="Password" />
                            </div>
                            <div class="form-group">
                                <button class="btn btn-primary btn-block" type="submit">
                                    Login
                                </button>
                            </div>
                        </form>

                        <div class="text-center forgotpass">
                            <a href="forgot-password.html">Forgot Password?</a>
                        </div>



                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.wrapper', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sms\resources\views/auth/login.blade.php ENDPATH**/ ?>