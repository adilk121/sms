@extends('layouts.wrapper')
@section('content')
<div class="main-wrapper login-body">
    <div class="login-wrapper">
        <div class="container">
            <div class="loginbox">
                <div class="login-left">
                    <img class="img-fluid" src="{{ asset('img/logo-white.png') }}" alt="Logo" />
                </div>
                <div class="login-right">
                    <div class="login-right-wrap">
                        <h1>Login</h1>
                        <p class="account-subtitle">Access to our dashboard</p>

                        <form action="{{ route('login') }}" method="POST">
                            @csrf
                            <div class="form-group">
                                <input class="form-control" type="text" name="email" id="email" placeholder="Email" />
                            </div>
                            <div class="form-group">
                                <input class="form-control" type="text" name="password" id="password" placeholder="Password" />
                            </div>
                            <div class="form-group">
                                <button class="btn btn-primary btn-block" type="submit">
                                    Login
                                </button>
                            </div>
                        </form>

                        <div class="text-center forgotpass">
                            <a href="forgot-password.html">Forgot Password?</a>
                        </div>



                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection