<?php

namespace App\Http\Controllers;

use App\Models\Guardian;
use App\Models\StudentClass;
use App\Models\Subject;
use App\Models\Student;
use App\Models\Teacher;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class PrincipalController extends Controller
{
    public function createStudent(Request $request)
    {
        // dd($request->all());
        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:users',
            'password' => 'required',
            'mobile' => 'required|digits:10',
            'dob' => 'required',
            'class_id' => 'required',
            'subjects' => 'required',
            'guardian_id' => 'required',
            'teacher_id' => 'required',
        ]);
        User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => 0,
        ]);
        $stdID = implode(",", $request->subjects);
        Student::create([
            'user_id' => User::latest()->first()->id,
            'mobile' => $request->mobile,
            'dob' => $request->dob,
            'class_id' => $request->class_id,
            'guardian_id' => $request->guardian_id,
            'teacher_id' => $request->teacher_id,
            'subjects' => $stdID,
            'gender' => $request->gender,
            'status' => 1,
        ]);
        return redirect()->back()->with('success', 'Student Created Successfully');
    }
    public function createTeacher(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required|email',
            'mobile' => 'required',
            'password' => 'required|confirmed',
            'gender' => 'required',
            'doj' => 'required',
        ]);

        User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => 2
        ]);
        Teacher::create([
            'mobile' => $request->mobile,
            'gender' => $request->gender,
            'user_id' => User::latest()->first()->id,
            'doj' => $request->doj,
            'status' => 2
        ]);
        return redirect()->back()->with('success', 'Teacher Created Successfully');
    }
    public function createGuardian(Request $request)
    {

        $request->validate([
            'name' => 'required',
            'email' => 'required|email',
            'mobile' => 'required',
            'password' => 'required',
            'gender' => 'required',
        ]);

        User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => 1
        ]);
        Guardian::create([
            'mobile' => $request->mobile,
            'gender' => $request->gender,
            'user_id' => User::latest()->first()->id,
            'status' => 1
        ]);
        return redirect()->back()->with('success', 'Guardian Created Successfully');
    }
    public function createClass(Request $request)
    {
        $request->validate([
            'name' => 'required',
        ]);

        StudentClass::create([
            'name' => $request->name,
        ]);
        return redirect()->back()->with('success', 'Class Created Successfully');
    }
    public function createSubject(Request $request)
    {
        $request->validate([
            'name' => 'required',
        ]);

        Subject::create([
            'name' => $request->name,
        ]);
        return redirect()->back()->with('success', 'Subject Created Successfully');
    }
}
